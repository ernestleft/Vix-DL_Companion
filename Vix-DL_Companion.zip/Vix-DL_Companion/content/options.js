"use strict";

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }

const _ = chrome.i18n.getMessage;

const checkHeadersPref = () => {
  document.getElementById("subtitlePref").disabled = false;
  document.getElementById("filePref").disabled = false;
  document.getElementById("headersPref").disabled = false;
  document.getElementById("titlePref").disabled = false;
  document.getElementById("filenamePref").disabled = false;
  document.getElementById("timestampPref").disabled = false;
  document.getElementById("fileExtension").disabled = true;
  document.getElementById("streamlinkOutput").disabled = true;
  document.getElementById("downloaderPref").disabled = true;
  document.getElementById("downloaderCommand").disabled = true;
  document.getElementById("proxyPref").disabled = false;
  document.getElementById("proxyCommand").disabled = true;
  document.getElementById("customCommandPref").disabled = false;
  document.getElementById("customCommand").disabled = true;
  document.getElementById("userCommand").disabled = true;
  document.getElementById("blacklistPref").disabled = false;
  document.getElementById("blacklistEntries").disabled = true;
  document.getElementById("cleanupPref").disabled = false;
  document.getElementById("notifDetectPref").disabled = false;
  document.getElementById("subtitlePref").disabled = document.getElementById("disablePref").checked;
  document.getElementById("filePref").disabled = document.getElementById("disablePref").checked;
  document.getElementById("notifDetectPref").disabled = document.getElementById("notifPref").checked;
  document.getElementById("downloaderCommand").disabled = !document.getElementById("downloaderPref").checked;
  document.getElementById("proxyCommand").disabled = !document.getElementById("proxyPref").checked;
  document.getElementById("customCommand").disabled = !document.getElementById("customCommandPref").checked;
  document.getElementById("blacklistEntries").disabled = !document.getElementById("blacklistPref").checked;

  if (document.getElementById("copyMethod").value === "url" || document.getElementById("copyMethod").value === "tableForm") {
    document.getElementById("headersPref").disabled = true;
    document.getElementById("filenamePref").disabled = true;
    document.getElementById("timestampPref").disabled = true;
    document.getElementById("proxyPref").disabled = true;
    document.getElementById("proxyCommand").disabled = true;
    document.getElementById("customCommandPref").disabled = true;
    document.getElementById("customCommand").disabled = true;
  } else if (document.getElementById("copyMethod").value === "kodiUrl") {
    document.getElementById("filenamePref").disabled = true;
    document.getElementById("timestampPref").disabled = true;
    document.getElementById("proxyPref").disabled = true;
    document.getElementById("proxyCommand").disabled = true;
    document.getElementById("customCommandPref").disabled = true;
    document.getElementById("customCommand").disabled = true;
  } else if (document.getElementById("copyMethod").value === "streamlink") {
    document.getElementById("streamlinkOutput").disabled = false;
  } else if (document.getElementById("copyMethod").value === "youtubedl" || document.getElementById("copyMethod").value === "ytdlp") {
    document.getElementById("downloaderPref").disabled = false;
  } else if (document.getElementById("copyMethod").value === "ffmpeg" || document.getElementById("copyMethod").value === "streamlink" || document.getElementById("copyMethod").value === "hlsdl") {
    document.getElementById("fileExtension").disabled = false;
  } else if (document.getElementById("copyMethod").value === "user") {
    document.getElementById("headersPref").disabled = false;
    document.getElementById("filenamePref").disabled = true;
    document.getElementById("timestampPref").disabled = true;
    document.getElementById("proxyPref").disabled = true;
    document.getElementById("proxyCommand").disabled = true;
    document.getElementById("customCommand").disabled = true;
    document.getElementById("userCommand").disabled = false;
  }
};

const saveOption = e => {
  var _e$target$value3;

  if (e.target.id === "copyMethod" && e.target.value !== "url" && e.target.value !== "tableForm" && e.target.value !== "kodiUrl") {
    const prefName = "customCommand" + e.target.value;
    if (localStorage.getItem(prefName)) document.getElementById("customCommand").value = localStorage.getItem(prefName) || "";
  }

  if (e.target.id === "customCommand") {
    var _e$target$value;

    localStorage.setItem(e.target.id + document.getElementById("copyMethod").value, JSON.stringify((_e$target$value = e.target.value) === null || _e$target$value === void 0 ? void 0 : _e$target$value.trim()));
  } else if (e.target.id === "blacklistEntries") {
    var _e$target$value2;

    localStorage.setItem(e.target.id, JSON.stringify((_e$target$value2 = e.target.value) === null || _e$target$value2 === void 0 ? void 0 : _e$target$value2.split("\n").filter(ee => ee)));
  } else if (e.target.type === "checkbox") {
    localStorage.setItem(e.target.id, JSON.stringify(e.target.checked));
  } else if (e.target.type === "text" && ((_e$target$value3 = e.target.value) === null || _e$target$value3 === void 0 ? void 0 : _e$target$value3.trim().length) === 0) {
    localStorage.removeItem(e.target.id);
  } else {
    var _e$target$value4;

    localStorage.setItem(e.target.id, JSON.stringify((_e$target$value4 = e.target.value) === null || _e$target$value4 === void 0 ? void 0 : _e$target$value4.trim()));
  }

  chrome.runtime.sendMessage({
    options: true
  });
  checkHeadersPref();
};

const restoreOptions = () => {
  const options = document.getElementsByClassName("option");

  var _iterator = _createForOfIteratorHelper(options),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      const option = _step.value;

      if (option.id === "customCommand") {
        const prefName = option.id + document.getElementById("copyMethod").value;
        document.getElementById(option.id).value = localStorage.getItem(prefName) || "";
      } else if (option.id === "blacklistEntries") {
        if (localStorage.getItem(option.id)) {
          const blacklistValue = JSON.parse(localStorage.getItem(option.id));
          document.getElementById(option.id).value = blacklistValue.join("\n");
        }
      } else if (localStorage.getItem(option.id) !== null) {
        if (document.getElementById(option.id).type === "checkbox" || document.getElementById(option.id).type === "radio") {
          document.getElementById(option.id).checked = JSON.parse(localStorage.getItem(option.id));
        } else {
          document.getElementById(option.id).value = JSON.parse(localStorage.getItem(option.id));
        }
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  checkHeadersPref();
};

document.addEventListener("DOMContentLoaded", () => {
  const options = document.getElementsByClassName("option");

  var _iterator2 = _createForOfIteratorHelper(options),
      _step2;

  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      const option = _step2.value;

      option.onchange = e => saveOption(e);
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }

  const labels = document.getElementsByTagName("label");

  var _iterator3 = _createForOfIteratorHelper(labels),
      _step3;

  try {
    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
      const label = _step3.value;
      label.textContent = _(label.htmlFor) + ":";
    }
  } catch (err) {
    _iterator3.e(err);
  } finally {
    _iterator3.f();
  }

  const selectOptions = document.getElementsByTagName("option");

  var _iterator4 = _createForOfIteratorHelper(selectOptions),
      _step4;

  try {
    for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
      const selectOption = _step4.value;
      if (!selectOption.textContent) selectOption.textContent = _(selectOption.value);
    }
  } catch (err) {
    _iterator4.e(err);
  } finally {
    _iterator4.f();
  }

  const spans = document.getElementsByTagName("span");

  var _iterator5 = _createForOfIteratorHelper(spans),
      _step5;

  try {
    for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
      const span = _step5.value;
      span.parentElement.title = _(span.id);
    }
  } catch (err) {
    _iterator5.e(err);
  } finally {
    _iterator5.f();
  }

  restoreOptions();
  chrome.runtime.onMessage.addListener(message => {
    if (message.options) restoreOptions();
  });
});
